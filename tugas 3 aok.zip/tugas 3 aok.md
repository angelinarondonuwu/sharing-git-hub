# masukan library yang akan kita gunakan
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# melakukan pembacaan pada dataset dalam format 
data = pd.read_excel('Data.xlsx')

```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 5 entries, 0 to 4
    Data columns (total 9 columns):
    Data Responden                                                                  5 non-null object
    Bisakah anda membedakan ms office dengan libre office?                          5 non-null int64
    Mampukah anda membuat laporan (dokumen/presentasi) menggunakan libre office?    5 non-null int64
    Menurut anda Microsoft powerpoint bisa memasukkan gambar/video?                 5 non-null int64
    Apakah bisa menggunakan simbol matematika di microsoft excel?                   5 non-null int64
    Apakah microsoft office sangat menunjang pendidikan di kampus?                  5 non-null int64
    Apakah anda sering menggunakan microsoft office?                                5 non-null int64
    Seberapa familiar anda menggunakan ms office?                                   5 non-null int64
    Bisakah anda membedakan antara file docx dan odt?                               5 non-null int64
    dtypes: int64(8), object(1)
    memory usage: 432.0+ bytes
    


```python
# print 10 data pertama dalam tabel (validasi input)
data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Data Responden</th>
      <th>Bisakah anda membedakan ms office dengan libre office?</th>
      <th>Mampukah anda membuat laporan (dokumen/presentasi) menggunakan libre office?</th>
      <th>Menurut anda Microsoft powerpoint bisa memasukkan gambar/video?</th>
      <th>Apakah bisa menggunakan simbol matematika di microsoft excel?</th>
      <th>Apakah microsoft office sangat menunjang pendidikan di kampus?</th>
      <th>Apakah anda sering menggunakan microsoft office?</th>
      <th>Seberapa familiar anda menggunakan ms office?</th>
      <th>Bisakah anda membedakan antara file docx dan odt?</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sangat Setuju</td>
      <td>125</td>
      <td>80</td>
      <td>330</td>
      <td>255</td>
      <td>354</td>
      <td>301</td>
      <td>255</td>
      <td>123</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Setuju</td>
      <td>187</td>
      <td>167</td>
      <td>125</td>
      <td>148</td>
      <td>106</td>
      <td>133</td>
      <td>171</td>
      <td>161</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Ragu - Ragu</td>
      <td>145</td>
      <td>176</td>
      <td>25</td>
      <td>59</td>
      <td>21</td>
      <td>43</td>
      <td>45</td>
      <td>147</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Tidak Setuju</td>
      <td>33</td>
      <td>56</td>
      <td>18</td>
      <td>19</td>
      <td>10</td>
      <td>12</td>
      <td>18</td>
      <td>45</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Sangat Tidak Setuju</td>
      <td>10</td>
      <td>23</td>
      <td>4</td>
      <td>15</td>
      <td>6</td>
      <td>8</td>
      <td>7</td>
      <td>18</td>
    </tr>
  </tbody>
</table>
</div>




```python
# melihat 5 data terakhir yang dimiliki
data.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Data Responden</th>
      <th>Bisakah anda membedakan ms office dengan libre office?</th>
      <th>Mampukah anda membuat laporan (dokumen/presentasi) menggunakan libre office?</th>
      <th>Menurut anda Microsoft powerpoint bisa memasukkan gambar/video?</th>
      <th>Apakah bisa menggunakan simbol matematika di microsoft excel?</th>
      <th>Apakah microsoft office sangat menunjang pendidikan di kampus?</th>
      <th>Apakah anda sering menggunakan microsoft office?</th>
      <th>Seberapa familiar anda menggunakan ms office?</th>
      <th>Bisakah anda membedakan antara file docx dan odt?</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sangat Setuju</td>
      <td>125</td>
      <td>80</td>
      <td>330</td>
      <td>255</td>
      <td>354</td>
      <td>301</td>
      <td>255</td>
      <td>123</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Setuju</td>
      <td>187</td>
      <td>167</td>
      <td>125</td>
      <td>148</td>
      <td>106</td>
      <td>133</td>
      <td>171</td>
      <td>161</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Ragu - Ragu</td>
      <td>145</td>
      <td>176</td>
      <td>25</td>
      <td>59</td>
      <td>21</td>
      <td>43</td>
      <td>45</td>
      <td>147</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Tidak Setuju</td>
      <td>33</td>
      <td>56</td>
      <td>18</td>
      <td>19</td>
      <td>10</td>
      <td>12</td>
      <td>18</td>
      <td>45</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Sangat Tidak Setuju</td>
      <td>10</td>
      <td>23</td>
      <td>4</td>
      <td>15</td>
      <td>6</td>
      <td>8</td>
      <td>7</td>
      <td>18</td>
    </tr>
  </tbody>
</table>
</div>




```python
# melihat dimensi data
data.shape
```




    (5, 9)




```python
# melihat feature apa saja yang dimiliki
data.columns
```




    Index([u'Data Responden',
           u'Bisakah anda membedakan ms office dengan libre office?',
           u'Mampukah anda membuat laporan (dokumen/presentasi) menggunakan libre office?',
           u'Menurut anda Microsoft powerpoint bisa memasukkan gambar/video?',
           u'Apakah bisa menggunakan simbol matematika di microsoft excel?',
           u'Apakah microsoft office sangat menunjang pendidikan di kampus?',
           u'Apakah anda sering menggunakan microsoft office?',
           u'Seberapa familiar anda menggunakan ms office?',
           u'Bisakah anda membedakan antara file docx dan odt?'],
          dtype='object')




```python
# deskripsi data
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bisakah anda membedakan ms office dengan libre office?</th>
      <th>Mampukah anda membuat laporan (dokumen/presentasi) menggunakan libre office?</th>
      <th>Menurut anda Microsoft powerpoint bisa memasukkan gambar/video?</th>
      <th>Apakah bisa menggunakan simbol matematika di microsoft excel?</th>
      <th>Apakah microsoft office sangat menunjang pendidikan di kampus?</th>
      <th>Apakah anda sering menggunakan microsoft office?</th>
      <th>Seberapa familiar anda menggunakan ms office?</th>
      <th>Bisakah anda membedakan antara file docx dan odt?</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5.000000</td>
      <td>5.000000</td>
      <td>5.000000</td>
      <td>5.000000</td>
      <td>5.000000</td>
      <td>5.000000</td>
      <td>5.000000</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>100.000000</td>
      <td>100.400000</td>
      <td>100.400000</td>
      <td>99.200000</td>
      <td>99.400000</td>
      <td>99.400000</td>
      <td>99.200000</td>
      <td>98.800000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>75.511589</td>
      <td>68.061002</td>
      <td>137.012043</td>
      <td>102.216437</td>
      <td>148.093889</td>
      <td>123.435408</td>
      <td>108.927499</td>
      <td>63.641182</td>
    </tr>
    <tr>
      <th>min</th>
      <td>10.000000</td>
      <td>23.000000</td>
      <td>4.000000</td>
      <td>15.000000</td>
      <td>6.000000</td>
      <td>8.000000</td>
      <td>7.000000</td>
      <td>18.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>33.000000</td>
      <td>56.000000</td>
      <td>18.000000</td>
      <td>19.000000</td>
      <td>10.000000</td>
      <td>12.000000</td>
      <td>18.000000</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>125.000000</td>
      <td>80.000000</td>
      <td>25.000000</td>
      <td>59.000000</td>
      <td>21.000000</td>
      <td>43.000000</td>
      <td>45.000000</td>
      <td>123.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>145.000000</td>
      <td>167.000000</td>
      <td>125.000000</td>
      <td>148.000000</td>
      <td>106.000000</td>
      <td>133.000000</td>
      <td>171.000000</td>
      <td>147.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>187.000000</td>
      <td>176.000000</td>
      <td>330.000000</td>
      <td>255.000000</td>
      <td>354.000000</td>
      <td>301.000000</td>
      <td>255.000000</td>
      <td>161.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# lihat korelasi antara features
# tapi, correlation does not imply causation
# if then are both above their mean (or both below),
# then this will produce a positive number,
# because a positivexpositive=positive, and likewise a
# negativexnegative=positive

# min_periode : int, optional => minimum number of observations required

# correlations = data.corr() #default: pearson
# correlationa = data.corr(method='spearman',min_periods=1)
# correlations = data.corr(method='pearson',min_periods=1)
correlations = data.corr(method='kendall')
correlations
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Bisakah anda membedakan ms office dengan libre office?</th>
      <th>Mampukah anda membuat laporan (dokumen/presentasi) menggunakan libre office?</th>
      <th>Menurut anda Microsoft powerpoint bisa memasukkan gambar/video?</th>
      <th>Apakah bisa menggunakan simbol matematika di microsoft excel?</th>
      <th>Apakah microsoft office sangat menunjang pendidikan di kampus?</th>
      <th>Apakah anda sering menggunakan microsoft office?</th>
      <th>Seberapa familiar anda menggunakan ms office?</th>
      <th>Bisakah anda membedakan antara file docx dan odt?</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Bisakah anda membedakan ms office dengan libre office?</th>
      <td>1.0</td>
      <td>0.8</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>Mampukah anda membuat laporan (dokumen/presentasi) menggunakan libre office?</th>
      <td>0.8</td>
      <td>1.0</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.8</td>
    </tr>
    <tr>
      <th>Menurut anda Microsoft powerpoint bisa memasukkan gambar/video?</th>
      <td>0.6</td>
      <td>0.4</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.6</td>
    </tr>
    <tr>
      <th>Apakah bisa menggunakan simbol matematika di microsoft excel?</th>
      <td>0.6</td>
      <td>0.4</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.6</td>
    </tr>
    <tr>
      <th>Apakah microsoft office sangat menunjang pendidikan di kampus?</th>
      <td>0.6</td>
      <td>0.4</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.6</td>
    </tr>
    <tr>
      <th>Apakah anda sering menggunakan microsoft office?</th>
      <td>0.6</td>
      <td>0.4</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.6</td>
    </tr>
    <tr>
      <th>Seberapa familiar anda menggunakan ms office?</th>
      <td>0.6</td>
      <td>0.4</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.6</td>
    </tr>
    <tr>
      <th>Bisakah anda membedakan antara file docx dan odt?</th>
      <td>1.0</td>
      <td>0.8</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# correlation map
# higher correlation are brighter
f,ax = plt.subplots(figsize=(20,20))
sns.heatmap(correlations, annot=True, linewidths=.5, fmt='.3f',
ax=ax)
plt.show
```




    <function matplotlib.pyplot.show>




![png](output_8_1.png)



```python

```
